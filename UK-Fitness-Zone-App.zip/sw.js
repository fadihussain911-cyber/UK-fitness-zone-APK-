const C='ukfz-v6',F=['./','./index.html','./manifest.json','./icon-192.png','./icon-512.png',...Array.from({length:10},(_,i)=>'./gym'+(i+1)+'.jpg')];
self.addEventListener('install',e=>{e.waitUntil(caches.open(C).then(c=>Promise.all(F.map(f=>c.add(new Request(f,{cache:'reload'})).catch(()=>{})))));self.skipWaiting()});
self.addEventListener('activate',e=>{e.waitUntil(caches.keys().then(k=>Promise.all(k.filter(x=>x!==C).map(x=>caches.delete(x)))));self.clients.claim()});
self.addEventListener('fetch',e=>{
  const q=e.request;if(q.method!=='GET'||!q.url.startsWith(self.location.origin))return;
  e.respondWith(Promise.race([fetch(q,{cache:'no-cache'}),new Promise((_,no)=>setTimeout(no,3000))])
    .then(r=>{if(r.ok){const cp=r.clone();caches.open(C).then(c=>c.put(q,cp))}return r})
    .catch(()=>caches.match(q)));
});
